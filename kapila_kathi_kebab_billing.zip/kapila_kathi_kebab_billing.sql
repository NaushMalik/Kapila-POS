-- ============================================
-- KAPILA KATHI KEBAB - BILLING SYSTEM DATABASE
-- ============================================

CREATE DATABASE IF NOT EXISTS kapila_billing;
USE kapila_billing;

-- ============================================
-- 1. BUSINESS SETTINGS TABLE
-- ============================================

CREATE TABLE business_info (
    id INT PRIMARY KEY AUTO_INCREMENT,
    business_name VARCHAR(150) NOT NULL,
    address TEXT,
    mobile VARCHAR(20),
    landline VARCHAR(20),
    gst_number VARCHAR(50),
    invoice_prefix VARCHAR(10) DEFAULT 'KKK',
    currency VARCHAR(10) DEFAULT 'INR',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- 2. MENU / PRODUCT TABLE
-- ============================================

CREATE TABLE products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    product_name VARCHAR(150) NOT NULL,
    category VARCHAR(100),
    price DECIMAL(10,2) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- 3. INVOICE MASTER TABLE
-- ============================================

CREATE TABLE invoices (
    id INT PRIMARY KEY AUTO_INCREMENT,
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    customer_name VARCHAR(150),
    customer_gst VARCHAR(50),
    customer_address TEXT,
    customer_contact VARCHAR(20),
    subtotal DECIMAL(12,2) DEFAULT 0.00,
    tax DECIMAL(12,2) DEFAULT 0.00,
    total DECIMAL(12,2) DEFAULT 0.00,
    payment_mode VARCHAR(50),
    payment_status VARCHAR(50) DEFAULT 'Pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================
-- 4. INVOICE ITEMS TABLE
-- ============================================

CREATE TABLE invoice_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    invoice_id INT,
    product_id INT,
    item_name VARCHAR(150),
    quantity INT NOT NULL,
    rate DECIMAL(10,2) NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
);

-- ============================================
-- 5. DASHBOARD SUMMARY VIEW
-- ============================================

CREATE VIEW dashboard_summary AS
SELECT
    COUNT(id) AS total_invoices,
    SUM(total) AS total_revenue,
    SUM(CASE WHEN payment_status = 'Paid' THEN total ELSE 0 END) AS paid_amount,
    SUM(CASE WHEN payment_status = 'Pending' THEN total ELSE 0 END) AS pending_amount
FROM invoices;

-- ============================================
-- 6. TOTAL INVOICES VIEW
-- ============================================

CREATE VIEW total_invoices_view AS
SELECT COUNT(*) AS total_invoices FROM invoices;

-- ============================================
-- 7. INVOICE GENERATOR PROCEDURE
-- ============================================

DELIMITER $$

CREATE PROCEDURE generate_invoice_number(OUT new_invoice_no VARCHAR(50))
BEGIN
    DECLARE invoice_count INT;
    DECLARE prefix VARCHAR(10);

    SELECT COUNT(*) + 1 INTO invoice_count FROM invoices;
    SELECT invoice_prefix INTO prefix FROM business_info LIMIT 1;

    SET new_invoice_no = CONCAT(prefix, '-', YEAR(CURDATE()), '-', LPAD(invoice_count, 4, '0'));
END$$

DELIMITER ;

-- ============================================
-- 8. INSERT DEFAULT BUSINESS DATA
-- ============================================

INSERT INTO business_info
(business_name, address, mobile, landline, gst_number)
VALUES
(
'Kapila Kathi Kebab',
'173, Dhole Patil Road, Shop No. 4, Nalini Chambers, Pune - 411001',
'7038204449',
'020-41280262',
NULL
);

-- ============================================
-- 9. INSERT DEFAULT MENU PRODUCTS
-- ============================================

INSERT INTO products (product_name, category, price) VALUES
('Chicken Kathi Kabab Roll (Single Filling)', 'Roll', 140.00),
('Chicken Kathi Kabab Roll (Double Filling)', 'Roll', 190.00),
('Chicken Tikka (Only Pieces)', 'Non-Veg', 240.00),
('Paneer Roll', 'Veg', 130.00),
('Aloo & Paneer Roll', 'Veg', 120.00),
('Aloo Roll', 'Veg', 110.00),
('Egg Roll', 'Egg', 60.00),
('Soft Drink', 'Beverage', 25.00);

-- ============================================
-- END OF FILE
-- ============================================
